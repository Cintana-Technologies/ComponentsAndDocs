export interface IShape { 
   draw(); 
}